/**
 * ������ȡAndroidϵͳǩ��֤�飨testKey.x509.pem���еĹ�Կ
 */

import java.io.*;
import java.math.BigInteger;
import java.security.cert.*;
import java.security.interfaces.RSAPublicKey;

class ExtractPubKey{
	public static void main(String args[]) throws IOException {
		if (args.length != 1) {
            System.err.println("Usage: java -jar ./SignAPKKey.jar xx/xx/xxxx.x509.pem");
            System.exit(2);
        }

		//����publicKey.txt�ļ���������ȡ�����Ĺ�Կ
		String pKeystr = "";
		File file = new File("publicKey.txt");		
		if (!file.exists()) {
			file.createNewFile();
		}		
		FileWriter keyfile = new FileWriter(file);
				
		//ͨ��֤��,��ȡ��Կ
		CertificateFactory cf = null;
		X509Certificate x509Cer = null;
		try {
			cf = CertificateFactory.getInstance("X.509");
		} catch (CertificateException e1) {
			e1.printStackTrace();
		}
		
		FileInputStream in = null;
		try {
			//in = new FileInputStream("C:\\Users\\l00176794\\workspace\\SignAPKKey\\bin\\huawei.x509.pem");
			in = new FileInputStream(args[0]);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		//����һ��֤�����ʹ�ô������� inStream �ж�ȡ������ת�����ַ�����
	  	Certificate c = null;
	  	try {
			c = cf.generateCertificate(in);
			x509Cer = (X509Certificate) c;			
		} catch (CertificateException e) {
			e.printStackTrace();
		}
	  	RSAPublicKey publicKey = null;
	  	publicKey = (RSAPublicKey) x509Cer.getPublicKey();
	  	BigInteger bigInt = null;
	  	bigInt = publicKey.getModulus();
	  	byte[] b = new byte[1024];
	  	b = bigInt.toByteArray();
	  	
	  	for (int i = 1; i < 257; i++) {
	  		pKeystr = pKeystr + Integer.toHexString((b[i] >> 4) & 0xF);
	  		pKeystr = pKeystr + Integer.toHexString(b[i] & 0xF);
	  	}
	  	keyfile.write(pKeystr);
	  	keyfile.close();
	}
} 