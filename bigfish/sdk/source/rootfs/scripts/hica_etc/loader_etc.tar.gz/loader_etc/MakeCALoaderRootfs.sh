#!/bin/sh

if [ $# -ne 1 ]
then
    echo -e "usage: ./MakeCALoaderRootfs.sh loader_rootfs_dir "
    echo -e "        for example: ./MakeCALoaderRootfs.sh /home/q00256878/HiSTBLinuxV100R002 "
    exit 1
fi

etc_dir=$1/source/rootfs/scripts/hica_etc/loader_etc
rootfs_dir=$1/pub/rootbox

STRIP=arm-hisiv200-linux-strip

if [ -d $etc_dir ];then
   echo "$etc_dir" 
else
   echo "$etc_dir is not exist"
   exit 1 
fi

if [ -d $rootfs_dir ];then
   echo "$rootfs_dir" 
else
   echo "$rootfs_dir is not exist"
   exit 1 
fi

rm -rf $rootfs_dir/etc/*
cp -af $etc_dir/etc/*  $rootfs_dir/etc/

#### copy the dynamic libraries needed by customer application in $(rootbox)/lib to the directory $(rootbox)/home/stb/usr/lib

usrlib_to_cp=" libfreetype.so.6.4.0 "
usrlib_to_cp+=" libfreetype.so.6 "
usrlib_to_cp+=" libfreetype.so "
usrlib_to_cp+=" libz.so.1.2.* "
usrlib_to_cp+=" libz.so.1 "
usrlib_to_cp+=" libz.so "

for ff in $usrlib_to_cp ; do
    cp -af $1/pub/lib/share/$ff 		$rootfs_dir/usr/lib
done

echo "***** delete unneed files in hica loader *******"

file_to_del=" $rootfs_dir/etc/init.d/S80network "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/54-gphoto.rules "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/60-pcmcia.rules "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/61-usb-phone.rules "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/75-cd-aliases-generator.rules.optional "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/75-persistent-net-generator.rules.optional "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/97-bluetooth-serial.rules "
file_to_del+=" $rootfs_dir/sbin/iptables* "                        
file_to_del+=" $rootfs_dir/sbin/iptables* "
file_to_del+=" $rootfs_dir/bin/him* "
file_to_del+=" $rootfs_dir/bin/mkntfs "
file_to_del+=" $rootfs_dir/bin/chkntfs "
file_to_del+=" $rootfs_dir/usr/share/udhcpc "

file_to_del+=" $rootfs_dir/etc/fs-version "
file_to_del+=" $rootfs_dir/etc/ld.so.conf "
file_to_del+=" $rootfs_dir/etc/mtab "
file_to_del+=" $rootfs_dir/etc/profile "
file_to_del+=" $rootfs_dir/etc/protocols "
file_to_del+=" $rootfs_dir/etc/services "
file_to_del+=" $rootfs_dir/etc/udev/firmware.sh "
file_to_del+=" $rootfs_dir/etc/udev/udev.conf "
file_to_del+=" $rootfs_dir/etc/udev/rules.d/99-fuse.rules "

file_to_del+=" $rootfs_dir/kmod/ddr3_reboot_loader.ko "
file_to_del+=" $rootfs_dir/kmod/hi_ci.ko "
file_to_del+=" $rootfs_dir/kmod/hi_e2prom.ko "
file_to_del+=" $rootfs_dir/kmod/hi_ndpt.ko "
file_to_del+=" $rootfs_dir/kmod/hi_ov7725.ko "
file_to_del+=" $rootfs_dir/kmod/hi_qtc.ko "
file_to_del+=" $rootfs_dir/kmod/hi_sci.ko "
file_to_del+=" $rootfs_dir/kmod/hi_sethdcp.ko "
file_to_del+=" $rootfs_dir/kmod/hi_ssp.ko "
file_to_del+=" $rootfs_dir/kmod/hi_tvp5150.ko "
file_to_del+=" $rootfs_dir/kmod/hi_usbprotected.ko "
file_to_del+=" $rootfs_dir/kmod/mono_uart.ko "
file_to_del+=" $rootfs_dir/kmod/tlv320.ko "
file_to_del+=" $rootfs_dir/kmod/tw2864.ko "
file_to_del+=" $rootfs_dir/kmod/wish_slac.ko "

file_to_del+=" $rootfs_dir/usr/lib/libhi_local_rec.so "
file_to_del+=" $rootfs_dir/usr/lib/libip4tc.* "
file_to_del+=" $rootfs_dir/usr/lib/libxtables.* "

file_to_del+=" $rootfs_dir/lib/libutil* "
file_to_del+=" $rootfs_dir/lib/libresolv* "
file_to_del+=" $rootfs_dir/lib/libpcprofile.so "
file_to_del+=" $rootfs_dir/lib/libmemusage.so "
file_to_del+=" $rootfs_dir/lib/libnsl* "
#file_to_del+=" $rootfs_dir/lib/libcrypt* "
file_to_del+=" $rootfs_dir/lib/libcidn* "
file_to_del+=" $rootfs_dir/lib/libanl* "
file_to_del+=" $rootfs_dir/lib/libSegFault* "
file_to_del+=" $rootfs_dir/lib/libBrokenLocale* "    
file_to_del+=" $rootfs_dir/lib/libBrokenLocale* "
file_to_del+=" $rootfs_dir/lib/libnss* "
file_to_del+=" $rootfs_dir/lib/firmware "
file_to_del+=" $rootfs_dir/dev/console "
file_to_del+=" $rootfs_dir/dev/tty* "

file_to_del+=" $rootfs_dir/dev/* "
file_to_del+=" $rootfs_dir/home/stb/* "

for ff in $file_to_del ; do
   rm  -rf $ff
done


# prepare different /etc/inittab for debug and release mode 
if [ "$CFG_FUNCTION_DEBUG" = "y" ]; then

# create console devnode
mknod $rootfs_dir/dev/console c 5 1

# start shell first
        cat <<EOF > $rootfs_dir/etc/inittab
::sysinit:/etc/init.d/rcS
::respawn:-/bin/sh
EOF
# start loader
	echo "" >> $rootfs_dir/etc/profile
        echo "sleep 3" >> $rootfs_dir/etc/profile
        echo "cd /home && ./loader" >> $rootfs_dir/etc/profile

else # release or final mode

	cat <<EOF > $rootfs_dir/bin/loader.sh
#!/bin/sh

/bin/sleep 3
cd /home  && ./loader

EOF
	chmod 755 $rootfs_dir/bin/loader.sh

	cat <<EOF > $rootfs_dir/etc/inittab
::sysinit:/etc/init.d/rcS
::respawn:/bin/loader.sh
EOF

fi

exit 0
