/****************************************************************************
 * Ralink Tech Inc.
 * Taiwan, R.O.C.
 *
 * (c) Copyright 2002, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************/

#ifndef CRYPT_GPL_ALGORITHM
/****************************************************************************
    Module Name:
    DH

    Abstract:
    RFC 2631: Diffie-Hellman Key Agreement Method
    
    Revision History:
    Who         When            What
    --------    ----------      ------------------------------------------
    Eddy        2009/01/21      Create Diffie-Hellman, Montgomery Algorithm
***************************************************************************/
#endif /* CRYPT_GPL_ALGORITHM */

#ifndef __CRYPT_DH_H__
#define __CRYPT_DH_H__

#ifdef CRYPT_TESTPLAN
#include "crypt_testplan.h"
#else
#include "rt_config.h"
#endif /* CRYPT_TESTPLAN */

#ifdef CRYPT_GPL_ALGORITHM

#define NN_DIGIT_BITS		32
#define DH_KEY_LEN			192
#define NN_DIGIT_LEN		4
#define MAX_NN_DIGITS		49

void GenerateDHPublicKey(unsigned char *ran_buf, int ran_len, 
                          unsigned char *dhkey, int *dhkey_len);

void GenerateDHSecreteKey(unsigned char *ran_buf, int ran_len,
                           unsigned char *peer_dhkey, int peer_dhkey_len,
                           unsigned char *secrete_dhkey, int *secrete_dhkey_len);

void DH_freeall(void);

#define RT_DH_PublicKey_Generate(GK, GKL, PV, PVL, PriK, PriKL, PubK, PubKL) \
    GenerateDHPublicKey((PriK), (PriKL), (unsigned char *) (PubK), (int *) (PubKL))
    
#define RT_DH_SecretKey_Generate(PubK, PubKL, PV, PVL, PriK, PriKL, SecK, SecKL) \
    GenerateDHSecreteKey((PriK), (PriKL), (PubK), (PubKL), (unsigned char *) (SecK), (int *) (SecKL))

#define RT_DH_FREE_ALL() DH_freeall()

#else /* CRYPT_GPL_ALGORITHM */

/* DH operations */
void DH_PublicKey_Generate (
    IN UINT8 GValue[],
    IN UINT GValueLength,
    IN UINT8 PValue[],
    IN UINT PValueLength,
    IN UINT8 PrivateKey[],
    IN UINT PrivateKeyLength,
    OUT UINT8 PublicKey[],
    INOUT UINT *PublicKeyLength);

void DH_SecretKey_Generate (
    IN UINT8 PublicKey[],
    IN UINT PublicKeyLength,
    IN UINT8 PValue[],
    IN UINT PValueLength,
    IN UINT8 PrivateKey[],
    IN UINT PrivateKeyLength,
    OUT UINT8 SecretKey[],
    INOUT UINT *SecretKeyLength);

#define RT_DH_PublicKey_Generate(GK, GKL, PV, PVL, PriK, PriKL, PubK, PubKL) \
    DH_PublicKey_Generate((GK), (GKL), (PV), (PVL), (PriK), (PriKL), (UINT8 *) (PubK), (UINT *) (PubKL))

#define RT_DH_SecretKey_Generate(PubK, PubKL, PV, PVL, PriK, PriKL, SecK, SecKL) \
    DH_SecretKey_Generate((PubK), (PubKL), (PV), (PVL), (PriK), (PriKL), (UINT8 *) (SecK), (UINT *) (SecKL))

#define RT_DH_FREE_ALL()

#endif /* CRYPT_GPL_ALGORITHM */
    
#endif /* __CRYPT_DH_H__ */

