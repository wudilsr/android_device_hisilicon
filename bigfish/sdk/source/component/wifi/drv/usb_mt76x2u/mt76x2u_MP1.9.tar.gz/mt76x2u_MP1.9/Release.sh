OSABL=NO
BaseCodeDir=`pwd`
ChipName="mt7612e"
DriverVersion="V3.0.2.7"
Release="DPA"
Note=$1
Description="Formal release."
release_profile=Release.log
###### Fixed Settings ######
Day=`date +%d`
Month=`date +%m`
Year=`date +%Y`
Date=$Year$Month$Day
Hour=`date +%H`
Minute=`date +%M`
HomeDir=`dirname $BaseCodeDir`
#ModuleName=mt$ChipName\_wifi_$DriverVersion
ModulePrefix=MT7612E_LinuxAP
ModuleName=$ModulePrefix\_$DriverVersion
WorkDir=$HomeDir/release
TargetDir=$WorkDir/$ModuleName\_$Date\_$Hour$Minute
############################

if [ ! -d $WorkDir ]; then
    mkdir $WorkDir
fi

BaseCodeDir=`readlink -f $BaseCodeDir` #get full path
if [ ! -d $BaseCodeDir ] ; then
    echo "Error: BaseCodeDir ($BaseCodeDir) does not exist."
	exit 1;
fi

cp -a $BaseCodeDir $TargetDir
if [ ! -d $TargetDir ] ; then
    echo "Error: TargetDir ($TargetDir) does not exist."
    exit 1;
fi

cd $TargetDir

if [ -f /home/haipin/script/chmod_644.sh ]; then
	/home/haipin/script/chmod_644.sh
fi

if [ -f /home/haipin/script/clean.sh ]; then
	/home/haipin/script/clean.sh
fi

for i in $Release; do
	cd $TargetDir
	####### Remove unwanted files that do not processed by strip tool #######
	rm os/linux/Makefile.libautoprovision.6
	#########################################################################

	if [ -d $i ]; then
		rm -rf $i
	fi

#	. awk '{if ($1 == "RELEASE") { print $1, $2, $i} else {print $0}}' Makefile > Makefile.$i
	#### a dummy way to generate the makefile ####
	if  [ "$i" == "DPA" ]; then
	    awk '{if ($1 == "RELEASE") { print $1, $2, "DPA"} else {print $0}}' Makefile > Makefile.temp
	elif [ "$i" == "DPB" ]; then
	    awk '{if ($1 == "RELEASE") { print $1, $2, "DPB"} else {print $0}}' Makefile > Makefile.temp
	elif [ "$i" == "DPC" ]; then
	    awk '{if ($1 == "RELEASE") { print $1, $2, "DPC"} else {print $0}}' Makefile > Makefile.temp
	elif [ "$i" == "DPD" ]; then
	    awk '{if ($1 == "RELEASE") { print $1, $2, "DPD"} else {print $0}}' Makefile > Makefile.temp
	elif [ "$i" == "ARCH" ]; then
	    awk '{if ($1 == "RELEASE") { print $1, $2, "ARCH"} else {print $0}}' Makefile > Makefile.temp
	else
	    cp Makefile Makefile.temp
	fi

	if  [ "$ChipName" == "7610e" ]; then
	    awk '{if ($1 == "CHIPSET") { print $1, $2, "mt7610e"} else {print $0}}' Makefile.temp > Makefile.temp2
	elif  [ "$ChipName" == "RBUS" ]; then
	    awk '{if ($1 == "CHIPSET") { print $1, $2, "RBUS"} else {print $0}}' Makefile.temp > Makefile.temp2
	elif  [ "$ChipName" == "mt7612e" ]; then
	    awk '{if ($1 == "CHIPSET") { print $1, $2, "mt7620 mt7662e mt7632e mt7612e"} else {print $0}}' Makefile.temp > Makefile.temp2
	else
	    echo "Error: unreconized ChipName ($ChipName)"
	    rm Makefile.temp
	    exit 1;
	fi
	
	if  [ "$OSABL" == "YES" ]; then
	    awk '{if ($1 == "OSABL") { print $1, $2, "YES"} else {print $0}}' Makefile.temp2 > Makefile
	elif [ "$OSABL" == "NO" ]; then
	    awk '{if ($1 == "OSABL") { print $1, $2, "NO"} else {print $0}}' Makefile.temp2 > Makefile
	else
	    echo "Error: unreconized OSABL ($OSABL)"
	    rm Makefile.temp Makefile.temp2
	    exit 1
	fi
	
	rm Makefile.temp Makefile.temp2
	
	##############################################

	make release
#	if [ -d $i ]; then
		lower=`echo $i | tr A-Z a-z`  #transfer "DPA DPB DPC DPD" to lower case
    	#ReleaseDir=$ModuleName\_$lower\_$Date
    	#ReleaseDir=$ModuleName\_$i\_$Date
    	#ReleaseDir=$ModuleName\_$Date
		ReleaseDir=$ModulePrefix
    	mv $i $ReleaseDir

		#if [ "$i" == "DPA" ]; then
			cd $ReleaseDir

			find . -name "*Card.dat" -exec rm -rf {} \;
			find . -name "*2870*.dat" -exec rm -rf {} \;
			rm -rf doc/*History*.txt doc/*README* doc/RT_WIFI_Revision_History_2010_April.xls doc/RT2860card.readme
			rm -rf Makefile.OSABL threadX.MakeFile vxworks.makefile
			rm -rf os/linux/Makefile.2880.*
			rm -rf Release.sh load.4 load.6 
			cd $TargetDir
		#fi
		
		### Generate profile for release ###
		echo $ModulePrefix > $ReleaseDir/$release_profile
		echo $DriverVersion >> $ReleaseDir/$release_profile
		echo $Date >> $ReleaseDir/$release_profile
		cp Pack_Release.sh $ReleaseDir/
		
		cd $ReleaseDir
		./Pack_Release.sh $1

    	#tar -jcvf $ReleaseDir.tar.bz2 $ReleaseDir
#	else
#		echo "Error: ReleaseDir ($i) does not exist"
#		exit 1
#	fi

done

#####Log File#####
if [ "$1" != "auto_build" ]; then
    cd $TargetDir
    echo "OSABL = $OSABL" > Release.log
    echo "BaseCodeDir = $BaseCodeDir" >> Release.log
    echo "ChipName = $ChipName" >> Release.log
    echo "DriverVersion = $DriverVersion" >> Release.log
    #echo "BuildDir = $BuildDir" >> Release.log
    echo "Release = $Release" >> Release.log
    if [ "$Description" != "" ]; then
        echo "Description = $Description" >> Release.log
    fi
    echo "Note: $Note" >> Release.log
fi
##################
