#!/bin/bash
# find lines ends with "#endif" in all *.c *.h files and append "// endif //" to avoid make release error
#filelist=$(grep -R "endif$" --exclude-dir=striptool --exclude=threadX.* --exclude=Makefile* ./* | awk 'BEGIN {FS=":"} {print $1}' |uniq |sort )
filelist_c=$(find . -type f -name "*.c" -exec grep -Rl "endif$" {} \; | grep -e ecos -e threadX -e win -e ucos -e vxworks -e striptool -v)
#echo $filelist_c
filelist_h=$(find . -type f -name "*.h" -exec grep -Rl "endif$" {} \; | grep -e ecos -e threadX -e win -e ucos -e vxworks -e striptool -v)
#echo $filelist_h
filelist=$(echo "$filelist_c $filelist_h")
echo $filelist

for file in $filelist
do 
	echo "process $file"
	cat $file | sed -e 's/#endif$/#endif \/\/ endif \/\/ /g' > $file.reform
	mv -f $file.reform $file
done
