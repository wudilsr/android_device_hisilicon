BaseCodeDir=`pwd`
HomeDir=`dirname $BaseCodeDir`
dir_main=rlt_wifi
dir_sta=rlt_wifi_sta
release_profile=Release.log
#module_name=`basename $BaseCodeDir`
module_name=`cat $release_profile | line`
release_version=`sed -e '1d' $release_profile | line`
release_date=`sed -e '1,2d' $release_profile | line`
package_name=$module_name\_$release_version\_$release_date
############################

	cd $HomeDir

	### Creat dir_main ###
	if [ -d $dir_main ]; then
		rm -rf $dir_main
	fi
	cp -a $BaseCodeDir $dir_main
	cp Kconfig $dir_main/
	rm $dir_main/Pack_Release_STA.sh $dir_main/Release.log

	### Creat dir_sta ###
	if [ -d $dir_sta ]; then
		rm -rf $dir_sta
	fi
	mkdir $dir_sta
	if [ ! -d $dir_sta ]; then
        echo "Error! Cannot creat folder [$dir_sta]"
		exit 1
    fi
	cp $BaseCodeDir/os/linux/Makefile.rlt_wifi_sta $dir_sta/Makefile
	cp $BaseCodeDir/os/linux/Kconfig.rlt_wifi_sta $dir_sta/Kconfig

	if [ "$1" == "auto_build" ]; then
		if [ -d ../$dir_main\_auto_build ]; then
			rm -rf ../$dir_main\_auto_build
		fi
		if [ -d ../$dir_sta\_auto_build ]; then
			rm -rf 	../$dir_sta\_auto_build
		fi
		mv $dir_main ../$dir_main\_auto_build
		mv $dir_sta ../$dir_sta\_auto_build
		cd ../../
		#rm -rf release 
	else
		tar -jcvf  $package_name\.tar.bz2 $dir_main $dir_sta
		rm -rf $dir_main $dir_sta
	fi

############################
