BaseCodeDir=`pwd`
HomeDir=`dirname $BaseCodeDir`
dir_main=rlt_wifi
dir_ap=rlt_wifi_ap
release_profile=Release.log
#module_name=`basename $BaseCodeDir`
module_name=`cat $release_profile | line`
release_version=`sed -e '1d' $release_profile | line`
release_date=`sed -e '1,2d' $release_profile | line`
package_name=$module_name\_$release_version\_$release_date
############################

	cd $HomeDir

	### Creat dir_main ###
	if [ -d $dir_main ]; then
		rm -rf $dir_main
	fi
	cp -a $BaseCodeDir $dir_main
	cp Kconfig $dir_main/
	rm $dir_main/Pack_Release.sh $dir_main/Release.log

	### Creat dir_ap ###
	if [ -d $dir_ap ]; then
		rm -rf $dir_ap
	fi
	mkdir $dir_ap
	if [ ! -d $dir_ap ]; then
        echo "Error! Cannot creat folder [$dir_ap]"
		exit 1
    fi
	cp $BaseCodeDir/os/linux/Makefile.rlt_wifi_ap $dir_ap/Makefile
	cp $BaseCodeDir/os/linux/Kconfig.rlt_wifi_ap $dir_ap/Kconfig

	if [ "$1" == "auto_build" ]; then
		if [ -d ../$dir_main\_auto_build ]; then
			rm -rf ../$dir_main\_auto_build
		fi
		if [ -d ../$dir_ap\_auto_build ]; then
			rm -rf 	../$dir_ap\_auto_build
		fi
		mv $dir_main ../$dir_main\_auto_build
		mv $dir_ap ../$dir_ap\_auto_build
		cd ../../
		#rm -rf release 
	else
		tar -jcvf  $package_name\.tar.bz2 $dir_main $dir_ap
		rm -rf $dir_main $dir_ap
	fi

############################
