/*
 ***************************************************************************
 * MediaTek Inc.
 * No. 1, Dusing 1st Rd., Hsinchu Science Park, Hsinchu City 30078, Taiwan
 *
 * (c) Copyright 2016 MediaTek, Inc.
 *
 * All rights reserved. MediaTek source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek Technology, Inc. is obtained.
 ***************************************************************************
 */
#ifndef	_MT76X2_VERSION_H_
#define _MT76X2_VERSION_H_

#define DRIVER_VERSION "JEDI.MP2.mt76x2u.wifi.v3.2.1"

#endif /* _MT76X2_VERSION_H_ */
