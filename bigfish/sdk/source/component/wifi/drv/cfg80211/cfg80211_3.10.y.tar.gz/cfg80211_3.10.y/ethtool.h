#ifndef __CFG80211_ETHTOOL__
#define __CFG80211_ETHTOOL__

extern const struct ethtool_ops cfg80211_ethtool_ops;

#endif /* __CFG80211_ETHTOOL__ */
